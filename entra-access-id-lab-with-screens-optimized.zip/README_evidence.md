# Lab Evidence (Screenshots)

Below are the proof-of-work screenshots for the **Microsoft Entra ID – Access & ID Tokens Lab**.
Each image is referenced with a brief caption. Replace any placeholder text with your own notes as needed.

![01-access-review-2-first-go.jpg](screenshots/01-access-review-2-first-go.jpg)

Screenshot 01: _Describe what this screenshot shows (e.g., App registration page, redirect URI, token claims)_.

![02-access-review-results.jpg](screenshots/02-access-review-results.jpg)

Screenshot 02: _Describe what this screenshot shows (e.g., App registration page, redirect URI, token claims)_.

![03-active-pim.jpg](screenshots/03-active-pim.jpg)

Screenshot 03: _Describe what this screenshot shows (e.g., App registration page, redirect URI, token claims)_.

![04-complete-access-review.jpg](screenshots/04-complete-access-review.jpg)

Screenshot 04: _Describe what this screenshot shows (e.g., App registration page, redirect URI, token claims)_.

![05-pim.jpg](screenshots/05-pim.jpg)

Screenshot 05: _Describe what this screenshot shows (e.g., App registration page, redirect URI, token claims)_.

![06-screenshot-2025-08-21-191935.jpg](screenshots/06-screenshot-2025-08-21-191935.jpg)

Screenshot 06: _Describe what this screenshot shows (e.g., App registration page, redirect URI, token claims)_.

![07-screenshot-2025-08-21-192113.jpg](screenshots/07-screenshot-2025-08-21-192113.jpg)

Screenshot 07: _Describe what this screenshot shows (e.g., App registration page, redirect URI, token claims)_.

![08-screenshot-2025-08-21-193910.jpg](screenshots/08-screenshot-2025-08-21-193910.jpg)

Screenshot 08: _Describe what this screenshot shows (e.g., App registration page, redirect URI, token claims)_.

![09-screenshot-2025-09-09-173755.jpg](screenshots/09-screenshot-2025-09-09-173755.jpg)

Screenshot 09: _Describe what this screenshot shows (e.g., App registration page, redirect URI, token claims)_.

![10-screenshot-2025-09-11-175539.jpg](screenshots/10-screenshot-2025-09-11-175539.jpg)

Screenshot 10: _Describe what this screenshot shows (e.g., App registration page, redirect URI, token claims)_.
