# Lab Evidence (Screenshots)

Below are the proof-of-work screenshots for the **Microsoft Entra ID – Access & ID Tokens Lab**. 
Each image is referenced with a brief caption. Replace any placeholder text with your own notes as needed.

![screenshots/01-access-review-2-first-go.png](screenshots/01-access-review-2-first-go.png)

Screenshot 01: _Describe what this screenshot shows (e.g., App registration page, redirect URI, token claims)_.

![screenshots/02-access-review-results.png](screenshots/02-access-review-results.png)

Screenshot 02: _Describe what this screenshot shows (e.g., App registration page, redirect URI, token claims)_.

![screenshots/03-active-pim.png](screenshots/03-active-pim.png)

Screenshot 03: _Describe what this screenshot shows (e.g., App registration page, redirect URI, token claims)_.

![screenshots/04-complete-access-review.png](screenshots/04-complete-access-review.png)

Screenshot 04: _Describe what this screenshot shows (e.g., App registration page, redirect URI, token claims)_.

![screenshots/05-pim.png](screenshots/05-pim.png)

Screenshot 05: _Describe what this screenshot shows (e.g., App registration page, redirect URI, token claims)_.

![screenshots/06-screenshot-2025-08-21-191935.png](screenshots/06-screenshot-2025-08-21-191935.png)

Screenshot 06: _Describe what this screenshot shows (e.g., App registration page, redirect URI, token claims)_.

![screenshots/07-screenshot-2025-08-21-192113.png](screenshots/07-screenshot-2025-08-21-192113.png)

Screenshot 07: _Describe what this screenshot shows (e.g., App registration page, redirect URI, token claims)_.

![screenshots/08-screenshot-2025-08-21-193910.png](screenshots/08-screenshot-2025-08-21-193910.png)

Screenshot 08: _Describe what this screenshot shows (e.g., App registration page, redirect URI, token claims)_.

![screenshots/09-screenshot-2025-09-09-173755.png](screenshots/09-screenshot-2025-09-09-173755.png)

Screenshot 09: _Describe what this screenshot shows (e.g., App registration page, redirect URI, token claims)_.

![screenshots/10-screenshot-2025-09-11-175539.png](screenshots/10-screenshot-2025-09-11-175539.png)

Screenshot 10: _Describe what this screenshot shows (e.g., App registration page, redirect URI, token claims)_.
